# Conteúdo da Landing Page - FJ Design Inox

## Seção 1: Hero Section
**Título Principal:** FJ Design Inox - Corrimão e Guarda-corpo em Aço Inox e Vidro

**Subtítulo:** Soluções arquitetônicas premium que combinam segurança, elegância e durabilidade. Projetos personalizados para residências, edifícios comerciais e espaços públicos.

**CTA Principal:** Solicitar Orçamento

**Imagem:** Projeto de destaque - Corrimão em inox com vidro em ambiente moderno

---

## Seção 2: Sobre a Empresa
**Título:** Excelência em Cada Detalhe

**Texto:** A FJ Design Inox é especializada em projetos de corrimão e guarda-corpo em aço inox e vidro. Com mais de uma década de experiência, transformamos espaços em ambientes seguros e esteticamente impecáveis. Nossa equipe de profissionais qualificados trabalha com os melhores materiais do mercado, garantindo qualidade, durabilidade e design inovador em cada projeto.

**Valores:**
- Qualidade Premium: Materiais de primeira linha e acabamento impecável
- Inovação: Designs modernos que acompanham tendências arquitetônicas
- Segurança: Conformidade com normas técnicas e regulamentações
- Atendimento Personalizado: Soluções customizadas para cada projeto

---

## Seção 3: Serviços
**Título:** Nossos Serviços

### Serviço 1: Corrimão em Inox
Corrimões elegantes e funcionais em aço inox para escadas, rampas e áreas de circulação. Designs personalizados que se adaptam a qualquer estilo arquitetônico.

### Serviço 2: Guarda-corpo em Vidro e Inox
Guarda-corpos modernos que combinam vidro temperado com estrutura em inox, oferecendo segurança sem comprometer a visibilidade e a estética.

### Serviço 3: Projetos Customizados
Soluções sob medida para projetos especiais, incluindo consultoria de design, fabricação e instalação profissional.

### Serviço 4: Manutenção e Limpeza
Serviços de manutenção preventiva e limpeza especializada para preservar a beleza e durabilidade dos seus projetos.

---

## Seção 4: Portfólio de Projetos
**Título:** Nossos Projetos

**Descrição:** Conheça alguns dos nossos trabalhos mais destacados. Cada projeto reflete nosso compromisso com excelência e inovação.

### Projeto 1: Residência Moderna - Corrimão Flutuante
Corrimão em inox polido com design minimalista em residência de luxo. Acabamento espelhado que reflete luz natural.

### Projeto 2: Edifício Comercial - Guarda-corpo em Vidro
Guarda-corpo em vidro temperado com estrutura em inox para sacada comercial. Segurança e transparência em perfeita harmonia.

### Projeto 3: Condomínio Residencial - Escada Monumental
Corrimão em inox escovado para escada de acesso principal. Design elegante que marca presença no ambiente.

### Projeto 4: Espaço Público - Rampa de Acessibilidade
Guarda-corpo em vidro e inox para rampa de acessibilidade. Combina segurança com design inclusivo.

---

## Seção 5: Diferenciais
**Título:** Por Que Escolher a FJ Design Inox?

**Diferenciais:**
- Materiais Premium: Aço inox 304 e 316, vidro temperado de alta qualidade
- Design Inovador: Equipe de designers especializados em arquitetura
- Instalação Profissional: Técnicos certificados e experientes
- Garantia Estendida: Cobertura completa dos serviços prestados
- Atendimento 24/7: Suporte técnico sempre disponível

---

## Seção 6: Processo de Trabalho
**Título:** Como Funciona Nosso Processo

**Passo 1: Consulta Inicial**
Reunião para entender suas necessidades, espaço e preferências de design.

**Passo 2: Projeto e Orçamento**
Apresentação de propostas personalizadas com visualizações 3D e orçamento detalhado.

**Passo 3: Fabricação**
Confecção do projeto em nossa oficina com controle de qualidade rigoroso.

**Passo 4: Instalação**
Instalação profissional por técnicos qualificados com mínimo de perturbação.

**Passo 5: Entrega e Suporte**
Entrega final, treinamento de manutenção e suporte contínuo.

---

## Seção 7: Testemunhos
**Título:** O Que Nossos Clientes Dizem

**Testemunho 1:**
"A FJ Design Inox transformou completamente a escada da minha casa. O corrimão é lindo e muito bem executado. Recomendo!" - João Silva, Residência Privada

**Testemunho 2:**
"Profissionalismo e qualidade impecável. O guarda-corpo do nosso edifício ficou exatamente como imaginávamos." - Maria Santos, Administradora de Condomínio

**Testemunho 3:**
"Equipe atenciosa e resultado final excepcional. Superaram nossas expectativas!" - Carlos Oliveira, Arquiteto

---

## Seção 8: Contato e CTA
**Título:** Entre em Contato

**Texto:** Pronto para transformar seu espaço? Entre em contato conosco para uma consulta gratuita e descubra como podemos ajudar seu projeto.

**Formulário de Contato:**
- Nome completo
- Email
- Telefone
- Tipo de Projeto (Residencial / Comercial / Público)
- Descrição do Projeto
- Botão: Enviar Mensagem

**Informações de Contato:**
- Email: contato@fjdesigninox.com.br
- Telefone: (11) 9999-9999
- Endereço: São Paulo, SP - Brasil
- Horário: Segunda a Sexta, 9h às 18h

**CTA Secundário:** Agendar Visita Técnica

---

## Seção 9: Rodapé
**Logo:** FJ Design Inox

**Links Rápidos:** Home, Serviços, Portfólio, Sobre, Contato

**Redes Sociais:** Instagram, Facebook, LinkedIn

**Copyright:** © 2026 FJ Design Inox. Todos os direitos reservados.

**Políticas:** Política de Privacidade | Termos de Serviço
