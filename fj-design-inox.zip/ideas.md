# Brainstorming de Design - FJ Design Inox

## Conceito Escolhido: **Modernismo Arquitetônico com Elegância Industrial**

### Design Movement
**Minimalismo Contemporâneo + Industrial Elegante**
Inspirado em arquitetura moderna, com ênfase na clareza, funcionalidade e beleza dos materiais (aço inox e vidro).

### Core Principles
1. **Transparência e Clareza** - Assim como o vidro, a comunicação deve ser cristalina
2. **Solidez e Confiança** - Aço inox representa durabilidade e qualidade premium
3. **Espaço Negativo Estratégico** - Layouts respirados que destacam projetos
4. **Precisão Geométrica** - Linhas limpas e proporções bem definidas

### Color Philosophy
- **Primária: Azul Profundo (#1a3a52)** - Representa confiança, profissionalismo e estabilidade
- **Secundária: Cinza Metálico (#8b92a0)** - Remete ao aço inox polido
- **Acentuada: Branco Puro (#ffffff)** - Transparência do vidro
- **Destaque: Azul Ciano (#00d4ff)** - Reflexo de luz em vidro/inox
- **Neutro: Cinza Claro (#f5f7fa)** - Fundo elegante

**Intenção Emocional:** Sofisticação, confiabilidade, modernidade e qualidade premium.

### Layout Paradigm
- **Hero Section Assimétrica** - Imagem de projeto em grande escala à direita, texto à esquerda
- **Grid de Portfólio Dinâmico** - Projetos em diferentes tamanhos (masonry-style)
- **Seções com Diagonal Dividers** - Transições suaves entre seções com ângulos
- **Sidebar Flutuante** - Elementos destacados em posição lateral
- **Tipografia Hierárquica** - Títulos grandes e ousados, corpo elegante e legível

### Signature Elements
1. **Linhas Geométricas Sutis** - Linhas diagonais e horizontais como divisores
2. **Reflexos de Luz** - Efeitos visuais que simulam reflexo em vidro/inox
3. **Ícones Minimalistas** - Representações simples de corrimão, vidro e segurança
4. **Gradientes Metálicos** - Transições suaves entre tons de cinza e azul

### Interaction Philosophy
- **Hover Effects Elegantes** - Elementos se elevam sutilmente ao passar o mouse
- **Transições Suaves** - Movimentos fluidos entre estados
- **Feedback Visual Claro** - Botões e links respondem imediatamente
- **Scroll Animations** - Elementos aparecem conforme o usuário desce a página

### Animation Guidelines
- **Entrada de Elementos** - Fade-in com slide suave (300ms)
- **Hover em Cards** - Elevação sutil (transform: translateY(-4px)) com sombra
- **Transição entre Seções** - Fade suave com parallax leve
- **Botões** - Scale suave (1.05) ao hover, feedback imediato
- **Scroll Reveal** - Elementos aparecem com opacity e transform

### Typography System
- **Display Font: Poppins Bold (700)** - Títulos principais (h1, h2)
- **Heading Font: Poppins SemiBold (600)** - Subtítulos (h3, h4)
- **Body Font: Inter Regular (400)** - Corpo de texto
- **Accent Font: Poppins Medium (500)** - Destaques e labels

**Hierarquia:**
- h1: 48px (desktop), 32px (mobile)
- h2: 36px (desktop), 24px (mobile)
- h3: 24px (desktop), 18px (mobile)
- Body: 16px (desktop), 14px (mobile)
- Small: 14px (desktop), 12px (mobile)

---

## Alternativas Exploradas (Não Selecionadas)

### Opção 2: Luxo Corporativo Clássico
- Paleta: Ouro + Preto + Branco
- Muito formal, menos diferenciado no mercado

### Opção 3: Tech Futurista Vibrante
- Paleta: Neon + Gradientes RGB
- Pode parecer datado rapidamente, menos apropriado para arquitetura

---

## Decisão Final
**Escolhido: Modernismo Arquitetônico com Elegância Industrial**

Esta abordagem reflete perfeitamente a natureza do negócio (arquitetura + materiais premium) enquanto mantém uma identidade visual sofisticada e atemporada.
