import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import ServicesSection from '@/components/ServicesSection';
import PortfolioSectionWithGallery from '@/components/PortfolioSectionWithGallery';
import ProcessSection from '@/components/ProcessSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      <main className="flex-1 pt-20">
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <PortfolioSectionWithGallery />
        <ProcessSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
