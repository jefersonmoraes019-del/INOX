import ImageGallery from '@/components/ImageGallery';

interface GalleryImage {
  id: number;
  title: string;
  description: string;
  image: string;
  category: string;
  fullImage?: string;
}

export default function PortfolioSectionWithGallery() {
  const galleryImages: GalleryImage[] = [
    {
      id: 1,
      title: 'Residência Moderna - Corrimão Flutuante',
      description: 'Corrimão em inox polido com design minimalista em residência de luxo. Acabamento espelhado que reflete luz natural, criando um efeito visual sofisticado e elegante.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_hero-PEcHavWGzmAej5qQj5P7oU.webp',
      fullImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_hero-N2tkiPuBHkXyRVpz3ToFnu.png',
      category: 'Residencial',
    },
    {
      id: 2,
      title: 'Edifício Comercial - Guarda-corpo em Vidro',
      description: 'Guarda-corpo em vidro temperado com estrutura em inox para sacada comercial. Segurança e transparência em perfeita harmonia, oferecendo visão panorâmica da cidade.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project2-UzPX3nsZ2pCmkSvsRo8Wti.webp',
      fullImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project2-9rgWPj2MoL5x6NNZVNE2Nh.png',
      category: 'Comercial',
    },
    {
      id: 3,
      title: 'Condomínio Residencial - Escada Monumental',
      description: 'Corrimão em inox escovado para escada de acesso principal. Design elegante que marca presença no ambiente, combinando funcionalidade com estética contemporânea.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project3-UvWuDCRjchVbKEnd2zyWW8.webp',
      fullImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project3-ThfcDQvLwUGtZfXyCcr246.png',
      category: 'Residencial',
    },
    {
      id: 4,
      title: 'Espaço Público - Rampa de Acessibilidade',
      description: 'Guarda-corpo em vidro e inox para rampa de acessibilidade. Combina segurança com design inclusivo, garantindo acesso seguro para todos os usuários.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project4-bnPgXhHu6nCWT9r5Z5ougE.webp',
      fullImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project4-Td7ZXMHjZTuyUzrpa7YKnL.png',
      category: 'Público',
    },
    {
      id: 5,
      title: 'Detalhe Premium - Acabamento em Inox Polido',
      description: 'Close-up mostrando a qualidade premium do acabamento em inox polido. Cada detalhe é cuidadosamente executado para garantir perfeição visual e durabilidade.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project1-MP3bUxip6urxJvTP58HGa3.webp',
      fullImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project1-PiTT2zDyuj52orFQ8C6ZUb.png',
      category: 'Detalhes',
    },
  ];

  return (
    <section id="portfolio" className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-bold text-primary mb-4 text-3xl md:text-4xl lg:text-5xl" style={{ fontFamily: "'Poppins', sans-serif" }}>
            Galeria de Projetos
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore nossa coleção de projetos realizados. Clique em qualquer imagem para visualizar detalhes completos e navegar pela galeria interativa.
          </p>
        </div>

        {/* Gallery Component */}
        <ImageGallery images={galleryImages} />
      </div>
    </section>
  );
}
