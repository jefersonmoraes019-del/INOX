import { Card } from '@/components/ui/card';

export default function PortfolioSection() {
  const projects = [
    {
      title: 'Residência Moderna - Corrimão Flutuante',
      description: 'Corrimão em inox polido com design minimalista em residência de luxo. Acabamento espelhado que reflete luz natural.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_hero-PEcHavWGzmAej5qQj5P7oU.webp',
      category: 'Residencial',
      size: 'col-span-1 row-span-2',
    },
    {
      title: 'Edifício Comercial - Guarda-corpo em Vidro',
      description: 'Guarda-corpo em vidro temperado com estrutura em inox para sacada comercial. Segurança e transparência em perfeita harmonia.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project2-UzPX3nsZ2pCmkSvsRo8Wti.webp',
      category: 'Comercial',
      size: 'col-span-1',
    },
    {
      title: 'Condomínio Residencial - Escada Monumental',
      description: 'Corrimão em inox escovado para escada de acesso principal. Design elegante que marca presença no ambiente.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project3-UvWuDCRjchVbKEnd2zyWW8.webp',
      category: 'Residencial',
      size: 'col-span-1',
    },
    {
      title: 'Espaço Público - Rampa de Acessibilidade',
      description: 'Guarda-corpo em vidro e inox para rampa de acessibilidade. Combina segurança com design inclusivo.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project4-bnPgXhHu6nCWT9r5Z5ougE.webp',
      category: 'Público',
      size: 'col-span-1',
    },
  ];

  return (
    <section id="portfolio" className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-bold text-primary mb-4 text-3xl md:text-4xl lg:text-5xl" style={{ fontFamily: "'Poppins', sans-serif" }}>Nossos Projetos</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Conheça alguns dos nossos trabalhos mais destacados. Cada projeto reflete nosso compromisso com excelência e inovação.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-[300px]">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="group relative overflow-hidden cursor-pointer border-0 shadow-md hover:shadow-xl transition-all duration-300"
            >
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <span className="text-accent text-sm font-semibold mb-2">{project.category}</span>
                <h3 className="font-bold text-white mb-2 text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>{project.title}</h3>
                <p className="text-white/90 text-sm leading-relaxed">{project.description}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
