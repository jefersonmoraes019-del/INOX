import { Card } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';

export default function ProcessSection() {
  const steps = [
    {
      number: '01',
      title: 'Consulta Inicial',
      description: 'Reunião para entender suas necessidades, espaço e preferências de design.',
    },
    {
      number: '02',
      title: 'Projeto e Orçamento',
      description: 'Apresentação de propostas personalizadas com visualizações 3D e orçamento detalhado.',
    },
    {
      number: '03',
      title: 'Fabricação',
      description: 'Confecção do projeto em nossa oficina com controle de qualidade rigoroso.',
    },
    {
      number: '04',
      title: 'Instalação',
      description: 'Instalação profissional por técnicos qualificados com mínimo de perturbação.',
    },
    {
      number: '05',
      title: 'Entrega e Suporte',
      description: 'Entrega final, treinamento de manutenção e suporte contínuo.',
    },
  ];

  return (
    <section id="processo" className="py-20 md:py-32 bg-white">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-bold text-primary mb-4 text-3xl md:text-4xl lg:text-5xl" style={{ fontFamily: "'Poppins', sans-serif" }}>Como Funciona Nosso Processo</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Um processo estruturado e transparente que garante qualidade em cada etapa.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 md:gap-6">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="p-6 h-full bg-card border border-border hover:shadow-lg transition-shadow">
                <div className="flex flex-col gap-4">
                  <div className="text-4xl font-bold text-accent/20" style={{ fontFamily: "'Poppins', sans-serif" }}>{step.number}</div>
                  <div className="flex flex-col gap-2">
                    <h3 className="font-semibold text-primary text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>{step.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                  </div>
                </div>
              </Card>

              {/* Arrow between steps */}
              {index < steps.length - 1 && (
                <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10">
                  <ArrowRight className="w-6 h-6 text-accent" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Mobile arrows */}
        <div className="lg:hidden flex justify-center mt-8 gap-2">
          {steps.map((_, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              {index < steps.length - 1 && <div className="w-4 h-0.5 bg-accent"></div>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
