import { Card } from '@/components/ui/card';
import { Zap, Layers, Wrench, Sparkles } from 'lucide-react';

export default function ServicesSection() {
  const services = [
    {
      icon: Zap,
      title: 'Corrimão em Inox',
      description: 'Corrimões elegantes e funcionais em aço inox para escadas, rampas e áreas de circulação. Designs personalizados que se adaptam a qualquer estilo arquitetônico.',
    },
    {
      icon: Layers,
      title: 'Guarda-corpo em Vidro e Inox',
      description: 'Guarda-corpos modernos que combinam vidro temperado com estrutura em inox, oferecendo segurança sem comprometer a visibilidade e a estética.',
    },
    {
      icon: Wrench,
      title: 'Projetos Customizados',
      description: 'Soluções sob medida para projetos especiais, incluindo consultoria de design, fabricação e instalação profissional.',
    },
    {
      icon: Sparkles,
      title: 'Manutenção e Limpeza',
      description: 'Serviços de manutenção preventiva e limpeza especializada para preservar a beleza e durabilidade dos seus projetos.',
    },
  ];

  return (
    <section id="servicos" className="py-20 md:py-32 bg-white">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-bold text-primary mb-4 text-3xl md:text-4xl lg:text-5xl" style={{ fontFamily: "'Poppins', sans-serif" }}>Nossos Serviços</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Oferecemos soluções completas em corrimão e guarda-corpo, desde o design até a instalação e manutenção.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card
                key={index}
                className="p-8 bg-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border border-border"
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-accent/10 rounded-lg flex-shrink-0">
                    <Icon className="w-6 h-6 text-accent" />
                  </div>
                  <div className="flex flex-col gap-3">
                    <h3 className="font-semibold text-primary text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>{service.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
