import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export default function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="flex flex-col gap-6 z-10">
            <div className="space-y-4">
              <div className="inline-block">
                <span className="px-4 py-2 bg-accent/10 text-accent rounded-full text-sm font-semibold">
                  ✨ Excelência em Arquitetura
                </span>
              </div>
              <h1 className="font-bold text-primary leading-tight text-4xl md:text-5xl lg:text-6xl" style={{ fontFamily: "'Poppins', sans-serif" }}>
                Corrimão e Guarda-corpo em Aço Inox e Vidro
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed max-w-lg">
                Soluções arquitetônicas premium que combinam segurança, elegância e durabilidade. Projetos personalizados para residências, edifícios comerciais e espaços públicos.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={() => scrollToSection('contato')}
                className="bg-primary hover:bg-primary/90 text-white font-semibold px-8 py-6 text-base flex items-center gap-2 group"
              >
                Solicitar Orçamento
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                onClick={() => scrollToSection('portfolio')}
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary/5 font-semibold px-8 py-6 text-base"
              >
                Ver Portfólio
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              <div>
                <p className="text-2xl md:text-3xl font-bold text-primary" style={{ fontFamily: "'Poppins', sans-serif" }}>100+</p>
                <p className="text-sm text-muted-foreground">Projetos Realizados</p>
              </div>
              <div>
                <p className="text-2xl md:text-3xl font-bold text-primary" style={{ fontFamily: "'Poppins', sans-serif" }}>10+</p>
                <p className="text-sm text-muted-foreground">Anos de Experiência</p>
              </div>
              <div>
                <p className="text-2xl md:text-3xl font-bold text-primary" style={{ fontFamily: "'Poppins', sans-serif" }}>500+</p>
                <p className="text-sm text-muted-foreground">Clientes Satisfeitos</p>
              </div>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative h-96 md:h-full min-h-96 lg:min-h-[600px]">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-primary/20 rounded-2xl blur-3xl"></div>
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_hero-PEcHavWGzmAej5qQj5P7oU.webp"
              alt="Corrimão em Inox Moderno"
              className="relative w-full h-full object-cover rounded-2xl shadow-2xl"
            />
            {/* Decorative Elements */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-accent/10 rounded-full blur-2xl"></div>
            <div className="absolute -top-6 -left-6 w-40 h-40 bg-primary/10 rounded-full blur-2xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
