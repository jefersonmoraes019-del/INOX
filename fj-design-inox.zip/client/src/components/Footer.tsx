import { Facebook, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-white py-16 md:py-20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="flex flex-col gap-4">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_logo_v2_option3-2RSDwpJ9L6WXtDNVfHELFe.png"
              alt="FJ Design Inox Logo"
              className="h-24 w-auto"
            />
            <p className="text-white/80 text-sm leading-relaxed">
              Soluções arquitetônicas premium em aço inox e vidro.
            </p>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col gap-4">
            <h4 className="font-semibold text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>Links Rápidos</h4>
            <nav className="flex flex-col gap-2">
              <a href="#sobre" className="text-white/80 hover:text-white transition-colors text-sm">
                Sobre
              </a>
              <a href="#servicos" className="text-white/80 hover:text-white transition-colors text-sm">
                Serviços
              </a>
              <a href="#portfolio" className="text-white/80 hover:text-white transition-colors text-sm">
                Portfólio
              </a>
              <a href="#processo" className="text-white/80 hover:text-white transition-colors text-sm">
                Processo
              </a>
            </nav>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col gap-4">
            <h4 className="font-semibold text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>Contato</h4>
            <div className="flex flex-col gap-2 text-sm">
              <a href="mailto:contato@fjdesigninox.com.br" className="text-white/80 hover:text-white transition-colors">
                contato@fjdesigninox.com.br
              </a>
              <a href="tel:+5511999999999" className="text-white/80 hover:text-white transition-colors">
                (11) 9999-9999
              </a>
              <p className="text-white/80">São Paulo, SP - Brasil</p>
            </div>
          </div>

          {/* Social Media */}
          <div className="flex flex-col gap-4">
            <h4 className="font-semibold text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>Redes Sociais</h4>
            <div className="flex gap-4">
              <a
                href="#"
                className="p-2 bg-white/10 hover:bg-accent rounded-lg transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="p-2 bg-white/10 hover:bg-accent rounded-lg transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="p-2 bg-white/10 hover:bg-accent rounded-lg transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/80">
            <p>&copy; {currentYear} FJ Design Inox. Todos os direitos reservados.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">
                Política de Privacidade
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Termos de Serviço
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
