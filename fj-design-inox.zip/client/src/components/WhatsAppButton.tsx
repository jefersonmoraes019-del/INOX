import { MessageCircle } from 'lucide-react';
import { useState } from 'react';

export default function WhatsAppButton() {
  const [isHovered, setIsHovered] = useState(false);
  
  const phoneNumber = '5511999999999';
  const message = 'Olá! Gostaria de solicitar um orçamento para meu projeto de corrimão e guarda-corpo.';
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="fixed bottom-8 right-8 z-40 group"
      aria-label="Contato via WhatsApp"
    >
      <div
        className={`absolute bottom-full right-0 mb-3 px-4 py-2 bg-gray-900 text-white text-sm rounded-lg whitespace-nowrap transition-all duration-300 ${
          isHovered ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        Fale conosco no WhatsApp
      </div>

      <div className="absolute inset-0 bg-green-500 rounded-full animate-pulse opacity-75"></div>
      
      <div
        className={`relative w-16 h-16 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 transform ${
          isHovered ? 'scale-110' : 'scale-100'
        }`}
      >
        <MessageCircle className="w-8 h-8 text-white" />
      </div>
    </a>
  );
}
