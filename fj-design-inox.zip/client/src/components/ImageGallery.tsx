import { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface GalleryImage {
  id: number;
  title: string;
  description: string;
  image: string;
  category: string;
  fullImage?: string;
}

interface ImageGalleryProps {
  images: GalleryImage[];
}

export default function ImageGallery({ images }: ImageGalleryProps) {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [filter, setFilter] = useState<string>('Todos');

  const categories = ['Todos', ...Array.from(new Set(images.map((img) => img.category)))];
  const filteredImages = filter === 'Todos' ? images : images.filter((img) => img.category === filter);

  const openLightbox = (imageId: number) => {
    const filteredIndex = filteredImages.findIndex((img) => img.id === imageId);
    setSelectedIndex(filteredIndex);
  };

  const closeLightbox = () => {
    setSelectedIndex(null);
  };

  const goToPrevious = () => {
    if (selectedIndex !== null) {
      setSelectedIndex((selectedIndex - 1 + filteredImages.length) % filteredImages.length);
    }
  };

  const goToNext = () => {
    if (selectedIndex !== null) {
      setSelectedIndex((selectedIndex + 1) % filteredImages.length);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') goToPrevious();
    if (e.key === 'ArrowRight') goToNext();
  };

  return (
    <div className="w-full">
      {/* Filter Buttons */}
      <div className="flex flex-wrap gap-3 mb-12 justify-center">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => {
              setFilter(category);
              setSelectedIndex(null);
            }}
            className={`px-6 py-2 rounded-full font-semibold transition-all ${
              filter === category
                ? 'bg-primary text-white shadow-lg'
                : 'bg-card text-foreground border border-border hover:border-primary'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredImages.map((image) => (
          <div
            key={image.id}
            onClick={() => openLightbox(image.id)}
            className="group relative overflow-hidden rounded-lg cursor-pointer shadow-md hover:shadow-xl transition-all duration-300 h-80"
          >
            <img
              src={image.image}
              alt={image.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
              <span className="text-accent text-sm font-semibold mb-2">{image.category}</span>
              <h3 className="font-bold text-white mb-2 text-lg" style={{ fontFamily: "'Poppins', sans-serif" }}>
                {image.title}
              </h3>
              <p className="text-white/90 text-sm leading-relaxed">{image.description}</p>
              <div className="mt-4 inline-flex items-center text-accent font-semibold text-sm">
                Ver Detalhes →
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {selectedIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
          onClick={closeLightbox}
          onKeyDown={handleKeyDown}
          role="dialog"
          aria-modal="true"
        >
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
            aria-label="Fechar galeria"
          >
            <X className="w-6 h-6 text-white" />
          </button>

          {/* Main Image */}
          <div className="relative w-full max-w-4xl max-h-[80vh] flex items-center justify-center">
            <img
              src={filteredImages[selectedIndex].fullImage || filteredImages[selectedIndex].image}
              alt={filteredImages[selectedIndex].title}
              className="w-full h-full object-contain rounded-lg"
            />

            {/* Navigation Buttons */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                goToPrevious();
              }}
              className="absolute left-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
              aria-label="Imagem anterior"
            >
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                goToNext();
              }}
              className="absolute right-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
              aria-label="Próxima imagem"
            >
              <ChevronRight className="w-6 h-6 text-white" />
            </button>
          </div>

          {/* Image Info */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 text-white">
            <h3 className="font-bold text-xl mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>
              {filteredImages[selectedIndex].title}
            </h3>
            <p className="text-white/90 mb-4">{filteredImages[selectedIndex].description}</p>
            <div className="flex items-center justify-between text-sm">
              <span className="text-accent font-semibold">{filteredImages[selectedIndex].category}</span>
              <span className="text-white/60">
                {selectedIndex + 1} de {filteredImages.length}
              </span>
            </div>
          </div>

          {/* Keyboard Hint */}
          <div className="absolute bottom-4 left-4 text-white/60 text-xs hidden md:block">
            <p>Setas: navegar | ESC: fechar</p>
          </div>
        </div>
      )}
    </div>
  );
}
