import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-border shadow-sm">
      <div className="container flex items-center justify-between h-20">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_logo_v2_option3-2RSDwpJ9L6WXtDNVfHELFe.png"
            alt="FJ Design Inox Logo"
            className="h-20 w-auto"
          />
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <button
            onClick={() => scrollToSection('sobre')}
            className="text-foreground hover:text-primary transition-colors font-medium text-sm"
          >
            Sobre
          </button>
          <button
            onClick={() => scrollToSection('servicos')}
            className="text-foreground hover:text-primary transition-colors font-medium text-sm"
          >
            Serviços
          </button>
          <button
            onClick={() => scrollToSection('portfolio')}
            className="text-foreground hover:text-primary transition-colors font-medium text-sm"
          >
            Portfólio
          </button>
          <button
            onClick={() => scrollToSection('processo')}
            className="text-foreground hover:text-primary transition-colors font-medium text-sm"
          >
            Processo
          </button>
          <button
            onClick={() => scrollToSection('contato')}
            className="text-foreground hover:text-primary transition-colors font-medium text-sm"
          >
            Contato
          </button>
        </nav>

        {/* CTA Button */}
        <div className="hidden md:flex">
          <Button
            onClick={() => scrollToSection('contato')}
            className="bg-primary hover:bg-primary/90 text-white font-semibold"
          >
            Solicitar Orçamento
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
        >
          {isMenuOpen ? (
            <X className="w-6 h-6 text-primary" />
          ) : (
            <Menu className="w-6 h-6 text-primary" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <nav className="md:hidden bg-white border-t border-border">
          <div className="container py-4 flex flex-col gap-4">
            <button
              onClick={() => scrollToSection('sobre')}
              className="text-foreground hover:text-primary transition-colors font-medium text-left py-2"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection('servicos')}
              className="text-foreground hover:text-primary transition-colors font-medium text-left py-2"
            >
              Serviços
            </button>
            <button
              onClick={() => scrollToSection('portfolio')}
              className="text-foreground hover:text-primary transition-colors font-medium text-left py-2"
            >
              Portfólio
            </button>
            <button
              onClick={() => scrollToSection('processo')}
              className="text-foreground hover:text-primary transition-colors font-medium text-left py-2"
            >
              Processo
            </button>
            <button
              onClick={() => scrollToSection('contato')}
              className="text-foreground hover:text-primary transition-colors font-medium text-left py-2"
            >
              Contato
            </button>
            <Button
              onClick={() => scrollToSection('contato')}
              className="bg-primary hover:bg-primary/90 text-white font-semibold w-full mt-2"
            >
              Solicitar Orçamento
            </Button>
          </div>
        </nav>
      )}
    </header>
  );
}
