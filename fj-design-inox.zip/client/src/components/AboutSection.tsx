import { CheckCircle2 } from 'lucide-react';

export default function AboutSection() {
  const values = [
    {
      title: 'Qualidade Premium',
      description: 'Materiais de primeira linha e acabamento impecável em cada projeto.',
      icon: '🏆',
    },
    {
      title: 'Inovação',
      description: 'Designs modernos que acompanham tendências arquitetônicas.',
      icon: '💡',
    },
    {
      title: 'Segurança',
      description: 'Conformidade com normas técnicas e regulamentações.',
      icon: '🔒',
    },
    {
      title: 'Atendimento Personalizado',
      description: 'Soluções customizadas para cada projeto único.',
      icon: '👥',
    },
  ];

  return (
    <section id="sobre" className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Image */}
          <div className="relative h-96 md:h-[500px]">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-3xl"></div>
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310419663028625646/dgqxfbXJEHi2xtSZabvzyP/fj_design_inox_project1-MP3bUxip6urxJvTP58HGa3.webp"
              alt="Detalhe de Corrimão em Inox"
              className="relative w-full h-full object-cover rounded-2xl shadow-lg"
            />
          </div>

          {/* Right Content */}
          <div className="flex flex-col gap-8">
            <div className="space-y-4">
              <h2 className="font-bold text-primary text-3xl md:text-4xl lg:text-5xl" style={{ fontFamily: "'Poppins', sans-serif" }}>Excelência em Cada Detalhe</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                A FJ Design Inox é especializada em projetos de corrimão e guarda-corpo em aço inox e vidro. Com mais de uma década de experiência, transformamos espaços em ambientes seguros e esteticamente impecáveis.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Nossa equipe de profissionais qualificados trabalha com os melhores materiais do mercado, garantindo qualidade, durabilidade e design inovador em cada projeto.
              </p>
            </div>

            {/* Values Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {values.map((value, index) => (
                <div key={index} className="flex gap-4">
                  <div className="text-3xl flex-shrink-0">{value.icon}</div>
                  <div className="flex flex-col gap-2">
                    <h4 className="font-semibold text-primary text-xl md:text-2xl" style={{ fontFamily: "'Poppins', sans-serif" }}>{value.title}</h4>
                    <p className="text-sm text-muted-foreground">{value.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
